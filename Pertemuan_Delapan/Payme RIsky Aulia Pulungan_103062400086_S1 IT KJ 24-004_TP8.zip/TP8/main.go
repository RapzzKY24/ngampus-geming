package main

import "fmt"

const NMAX = 1000

type tabInt [NMAX]float64

func masukan(A *tabInt, x int) {
	for i := 0; i < x; i++ {
		fmt.Printf("Berat ikan ke-%d: ", i+1)
		fmt.Scan(&(*A)[i])
	}
}

func totalBerat(A tabInt, x, y int) []float64 {
	var hasil []float64
	for i := 0; i < x; i += y {
		total := 0.0
		for j := i; j < i+y && j < x; j++ {
			total += A[j]
		}
		hasil = append(hasil, total)
	}
	return hasil
}

func rataRata(berat []float64) float64 {
	total := 0.0
	for _, b := range berat {
		total += b
	}
	return total / float64(len(berat))
}

func cariRinganBerat(berat []float64) (int, float64, int, float64) {
	idxRingan, idxBerat := 0, 0
	ringan, beratMax := berat[0], berat[0]
	for i, b := range berat {
		if b < ringan {
			ringan = b
			idxRingan = i
		}
		if b > beratMax {
			beratMax = b
			idxBerat = i
		}
	}
	return idxRingan, ringan, idxBerat, beratMax
}

func main() {
	var A tabInt
	var n, y int

	fmt.Print("Masukkan jumlah ikan: ")
	fmt.Scan(&n)

	fmt.Print("Masukkan kapasitas per wadah: ")
	fmt.Scan(&y)

	fmt.Println("Masukkan berat masing-masing ikan: ")
	masukan(&A, n)

	beratKelompok := totalBerat(A, n, y)
	fmt.Println("\nTotal berat ikan di setiap wadah:")
	for i, berat := range beratKelompok {
		fmt.Printf("Wadah %d: %.2f kg\n", i+1, berat)
	}

	rata := rataRata(beratKelompok)
	fmt.Printf("\nBerat rata-rata antar wadah: %.2f kg\n", rata)

	idxRingan, ringan, idxBerat, beratMax := cariRinganBerat(beratKelompok)
	fmt.Printf("Wadah paling ringan adalah wadah ke-%d dengan berat %.2f kg\n", idxRingan+1, ringan)
	fmt.Printf("Wadah paling berat adalah wadah ke-%d dengan berat %.2f kg\n", idxBerat+1, beratMax)
}
